import { cn } from "@/lib/utils";

interface StrengthMeterProps {
  password: string;
  length: number;
}

// Calculate password strength based on length and character variety
const calculateStrength = (password: string, length: number): { level: 'weak' | 'moderate' | 'strong', percentage: number } => {
  if (!password || length === 0) {
    return { level: 'weak', percentage: 0 };
  }

  let score = 0;
  
  // Length contribution (max 40 points)
  score += Math.min(length * 2, 40);
  
  // Character variety contribution (max 60 points)
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^a-zA-Z0-9]/.test(password);
  
  const varietyCount = [hasLower, hasUpper, hasNumber, hasSpecial].filter(Boolean).length;
  score += varietyCount * 15;

  const percentage = Math.min(score, 100);
  
  // Determine strength level
  let level: 'weak' | 'moderate' | 'strong';
  if (length < 10) {
    level = 'weak';
  } else if (length < 16) {
    level = 'moderate';
  } else {
    level = 'strong';
  }

  return { level, percentage };
};

const StrengthMeter = ({ password, length }: StrengthMeterProps) => {
  const { level, percentage } = calculateStrength(password, length);

  const strengthConfig = {
    weak: {
      color: 'bg-strength-weak',
      label: 'Weak',
      textColor: 'text-strength-weak',
    },
    moderate: {
      color: 'bg-strength-moderate',
      label: 'Moderate',
      textColor: 'text-strength-moderate',
    },
    strong: {
      color: 'bg-strength-strong',
      label: 'Strong',
      textColor: 'text-strength-strong',
    },
  };

  const config = strengthConfig[level];

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">Password Strength</span>
        <span className={cn("font-semibold transition-colors", config.textColor)}>
          {config.label}
        </span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-500 ease-out",
            config.color
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default StrengthMeter;
