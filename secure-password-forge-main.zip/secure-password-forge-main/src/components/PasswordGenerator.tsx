import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Copy, RefreshCw, Shield } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import StrengthMeter from "./StrengthMeter";
import { cn } from "@/lib/utils";

const PasswordGenerator = () => {
  const [length, setLength] = useState(16);
  const [password, setPassword] = useState("");
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    special: true,
  });

  // Character sets for password generation
  const charSets = {
    uppercase: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    lowercase: "abcdefghijklmnopqrstuvwxyz",
    numbers: "0123456789",
    special: "!@#$%^&*()_+-=[]{}|;:,.<>?",
  };

  // Generate password based on selected options
  const generatePassword = () => {
    // Check if at least one option is selected
    const hasOptions = Object.values(options).some((value) => value);
    
    if (!hasOptions) {
      toast({
        title: "No options selected",
        description: "Please select at least one character type.",
        variant: "destructive",
      });
      return;
    }

    let availableChars = "";
    
    // Build character set based on selected options
    if (options.uppercase) availableChars += charSets.uppercase;
    if (options.lowercase) availableChars += charSets.lowercase;
    if (options.numbers) availableChars += charSets.numbers;
    if (options.special) availableChars += charSets.special;

    // Generate random password
    let newPassword = "";
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * availableChars.length);
      newPassword += availableChars[randomIndex];
    }

    setPassword(newPassword);
  };

  // Copy password to clipboard
  const copyToClipboard = async () => {
    if (!password) {
      toast({
        title: "No password to copy",
        description: "Generate a password first.",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(password);
      toast({
        title: "Copied!",
        description: "Password copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy password to clipboard.",
        variant: "destructive",
      });
    }
  };

  // Toggle option handler
  const toggleOption = (key: keyof typeof options) => {
    setOptions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-background to-secondary/30">
      <Card className="w-full max-w-md p-8 shadow-lg backdrop-blur-sm bg-card/95 border-border/50">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Strong Password Generator
          </h1>
          <p className="text-muted-foreground">
            Create secure passwords in seconds
          </p>
        </div>

        {/* Password Display */}
        <div className="mb-6">
          <Label htmlFor="password-display" className="text-sm font-medium mb-2 block">
            Generated Password
          </Label>
          <div className="relative">
            <input
              id="password-display"
              type="text"
              value={password}
              readOnly
              placeholder="Click generate to create password"
              className={cn(
                "w-full px-4 py-3 pr-12 rounded-lg border bg-secondary/50 text-foreground",
                "font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/50",
                "transition-all placeholder:text-muted-foreground/50"
              )}
            />
            <Button
              size="icon"
              variant="ghost"
              onClick={copyToClipboard}
              disabled={!password}
              className="absolute right-2 top-1/2 -translate-y-1/2 hover:bg-primary/10 hover:text-primary transition-colors"
              aria-label="Copy password"
            >
              <Copy className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Strength Meter */}
        {password && (
          <div className="mb-6">
            <StrengthMeter password={password} length={length} />
          </div>
        )}

        {/* Length Slider */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <Label htmlFor="length-slider" className="text-sm font-medium">
              Password Length
            </Label>
            <span className="text-sm font-semibold text-primary bg-primary/10 px-3 py-1 rounded-full">
              {length}
            </span>
          </div>
          <Slider
            id="length-slider"
            min={8}
            max={32}
            step={1}
            value={[length]}
            onValueChange={(value) => setLength(value[0])}
            className="cursor-pointer"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>8</span>
            <span>32</span>
          </div>
        </div>

        {/* Character Type Options */}
        <div className="space-y-3 mb-8">
          <Label className="text-sm font-medium">Include Characters</Label>
          
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors">
            <Checkbox
              id="uppercase"
              checked={options.uppercase}
              onCheckedChange={() => toggleOption("uppercase")}
            />
            <Label
              htmlFor="uppercase"
              className="flex-1 cursor-pointer font-normal"
            >
              Uppercase (A-Z)
            </Label>
          </div>

          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors">
            <Checkbox
              id="lowercase"
              checked={options.lowercase}
              onCheckedChange={() => toggleOption("lowercase")}
            />
            <Label
              htmlFor="lowercase"
              className="flex-1 cursor-pointer font-normal"
            >
              Lowercase (a-z)
            </Label>
          </div>

          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors">
            <Checkbox
              id="numbers"
              checked={options.numbers}
              onCheckedChange={() => toggleOption("numbers")}
            />
            <Label
              htmlFor="numbers"
              className="flex-1 cursor-pointer font-normal"
            >
              Numbers (0-9)
            </Label>
          </div>

          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors">
            <Checkbox
              id="special"
              checked={options.special}
              onCheckedChange={() => toggleOption("special")}
            />
            <Label
              htmlFor="special"
              className="flex-1 cursor-pointer font-normal"
            >
              Special (!@#$%^&*)
            </Label>
          </div>
        </div>

        {/* Generate Button */}
        <Button
          onClick={generatePassword}
          className="w-full py-6 text-base font-semibold bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-md"
          size="lg"
        >
          <RefreshCw className="w-5 h-5 mr-2" />
          Generate Password
        </Button>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-6">
          All passwords are generated locally and never sent to any server
        </p>
      </Card>
    </div>
  );
};

export default PasswordGenerator;
