import PasswordGenerator from "@/components/PasswordGenerator";

const Index = () => {
  return <PasswordGenerator />;
};

export default Index;
