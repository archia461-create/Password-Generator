# 🔐 Strong Password Generator

A modern, clean, and secure password generator built with React, TypeScript, and Tailwind CSS. Generate strong passwords with customizable options and real-time strength indicators.

![Strong Password Generator](https://img.shields.io/badge/Security-Password%20Generator-teal)
![React](https://img.shields.io/badge/React-18.3-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue)
![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.x-06B6D4)

## ✨ Features

- **Customizable Length**: Generate passwords between 8-32 characters
- **Character Options**: Toggle uppercase, lowercase, numbers, and special characters
- **Real-time Strength Indicator**: Visual feedback on password strength (Weak/Moderate/Strong)
- **One-Click Copy**: Copy generated passwords to clipboard instantly
- **Responsive Design**: Works seamlessly on mobile and desktop devices
- **Client-Side Only**: All generation happens locally - no data sent to servers
- **Beautiful UI**: Modern design with smooth animations and gradients

## 🚀 Live Demo

https://secure-password-forge.vercel.app/

## 📸 Screenshots

![Password Generator Interface](screenshot.png)

## 🛠️ Technology Stack

- **Framework**: React 18.3 with TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **Icons**: Lucide React
- **State Management**: React Hooks

## 📦 Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/strong-password-generator.git

# Navigate to project directory
cd strong-password-generator

# Install dependencies
npm install

# Start development server
npm run dev
```

## 🎯 Usage

1. **Adjust Password Length**: Use the slider to select your desired password length (8-32 characters)
2. **Select Character Types**: Check/uncheck options for:
   - Uppercase letters (A-Z)
   - Lowercase letters (a-z)
   - Numbers (0-9)
   - Special characters (!@#$%^&*)
3. **Generate**: Click "Generate Password" to create a new password
4. **Copy**: Click the copy icon to copy the password to your clipboard
5. **Check Strength**: View the real-time strength indicator below the password field

## 🔒 Security Features

- **Client-Side Generation**: All passwords are generated locally in your browser
- **No Server Communication**: Your passwords never leave your device
- **Cryptographically Secure**: Uses JavaScript's built-in random number generation
- **No Storage**: Passwords are not saved or stored anywhere

## 📁 Project Structure

```
src/
├── components/
│   ├── ui/                    # shadcn/ui components
│   ├── PasswordGenerator.tsx  # Main password generator component
│   └── StrengthMeter.tsx     # Password strength indicator
├── pages/
│   └── Index.tsx             # Main page
├── hooks/
│   └── use-toast.ts          # Toast notification hook
├── lib/
│   └── utils.ts              # Utility functions
├── App.tsx                   # App wrapper with routing
├── index.css                 # Global styles & design system
└── main.tsx                  # Entry point

.kiro/                         # Kiro AI assistance folder
public/                        # Static assets
```

## 🎨 Design System

The project uses a cohesive design system with:

- **Colors**: Professional teal/slate palette for trust and security
- **Typography**: Inter font family for modern, clean readability
- **Shadows**: Subtle layered shadows for depth
- **Transitions**: Smooth animations with cubic-bezier easing
- **Components**: Customized shadcn/ui components

## 🤖 How Kiro Helped

This project was built with assistance from Kiro AI, which provided:

- **Component Architecture**: Suggested clean separation between PasswordGenerator and StrengthMeter
- **Design System**: Helped establish a cohesive color palette and styling approach
- **TypeScript Types**: Provided proper type definitions for all components
- **Security Logic**: Assisted with implementing secure password generation algorithms
- **UX Improvements**: Suggested real-time feedback and visual indicators
- **Accessibility**: Ensured proper ARIA labels and keyboard navigation

The `.kiro` folder contains documentation and references from the AI-assisted development process.

## 🎯 Password Strength Algorithm

Passwords are evaluated based on:

- **Length Score**: Up to 40 points (2 points per character)
- **Variety Score**: Up to 60 points (15 points per character type)

Strength Levels:
- **Weak**: < 10 characters
- **Moderate**: 10-16 characters
- **Strong**: > 16 characters

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📝 Scripts

```bash
# Development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint
```

## 🚀 Deployment

### Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Deploy to Netlify

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Deploy
netlify deploy --prod
```

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Contact

For questions or feedback, please open an issue on GitHub.

---

**Built with ❤️ using React, TypeScript, and Tailwind CSS**

**AI-Assisted Development powered by Kiro**
